﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class RationalLabel : UserControl
    {
        public RationalLabel()
        {
            InitializeComponent();
        }

        public Digit Numerator
        {
            set { Num.Text = value.ToString(); }
        }

        public Natural Denominator
        {
            set { Denom.Text = value.ToString(); }
        }

        public Rational Value
        {
            set
            {
                Numerator = value.Numerator;
                Denominator = value.Denominator;
                this.Width = Math.Max(Num.Width, Denom.Width) + 5;
            }
            get { return new Rational(Num.Text, Denom.Text); }
        }

        public void Unknown()
        {
            Num.Text = "?";
            Denom.Text = "?";
        }

        private void RationalLabel_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Pen p = new Pen(Color.DarkGray, 1);
            int Y = (Num.Top + Num.Height + Denom.Top) / 2;
            int len = Math.Max(Num.Width, Denom.Width);
            g.DrawLine(p, Num.Left - 3, Y, Num.Left + len + 3, Y);
        }
    }
}
