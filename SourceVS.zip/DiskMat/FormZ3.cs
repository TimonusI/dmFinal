﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormZ3 : DiskMat.Module
    {

        public FormZ3()
        {
            Text = "Z_3";

            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            label2.Text = "* (-1) = ?";
        }
        public override void Run()
        {
            label2.Text = "* (-1) = " + Z_3.Run(inputBox2.Value).ToString();
            
        }

        public override void Resize()
        {
            this.Width = label2.Location.X + label2.Width + 25;
        }
    }
}
