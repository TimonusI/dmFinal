﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormN3 : DiskMat.Module
    {
        public FormN3()
        {
            Text = "N_3";
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(Errors.Count == 0)
                inputBox2.Text = N_3.Run(new Natural(inputBox2.Text)).ToString();
        }

        public override void Run()
        {
            button1.Enabled = true;
        }

        public override void ErrorHandle()
        {
            button1.Enabled = false;
        }
    }
}
