﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormZ6 : DiskMat.Module
    {

        public FormZ6()
        {
            Text = "Z_6";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            label2.Text = " = ?";
        }
        public override void Run()
        {
            label2.Text = " = " + Z_6.Run(inputBox2.Value, inputBox1.Value).ToString();

        }

        public override void Resize()
        {
            this.Width = label2.Location.X + label2.Width + 25;
        }

    }
}
