﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormZ5 : DiskMat.Module
    {
        public FormZ5()
        {
            Text = "Z_5";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            label2.Text = " = ?";
        }
        public override void Run()
        {
            label2.Text = " = " + Z_5.Run(inputBox2.Value).ToString();

        }

        public override void Resize()
        {
            this.Width = label2.Location.X + label2.Width + 50;
        }

        public override void SpecialConditionHandle()
        {
            ErrorBorder(inputBox2);
            ErrorLabel.Text = "Число не может быть положительным";
            ErrorHandle();
            
        }
    }
}
