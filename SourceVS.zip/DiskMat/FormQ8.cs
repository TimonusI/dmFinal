﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormQ8 : DiskMat.Module
    {
        public FormQ8()
        {
            Text = "Q_8";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            rationalLabel1.Unknown();
        }
        public override void Run()
        {
            rationalLabel1.Value = Q_8.Run(rationalBox1.Value, rationalBox2.Value);
        }

        public override void Resize()
        {
            this.Width = 25 + rationalLabel1.Left + rationalLabel1.Width;
        }


        public override void SpecialConditionHandle()
        {
            ErrorBorder(rationalBox2.NumBox);
            ErrorLabel.Text = "Деление на ноль недопустимо";
            ErrorHandle();
            rationalLabel1.Unknown();
            Resize();
        }
    }
}
