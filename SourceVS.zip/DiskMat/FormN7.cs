﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormN7 : DiskMat.Module
    {
        public FormN7()
        {
            Text = "N_7";
            InitializeComponent();
        }

        public override void Run()
        {
            label2.Text = "= " + N_7.Run(inputBox1.Value, Int32.Parse(inputBox2.Text));
            this.Width = label2.Location.X + label2.Width + 25;
        }

        public override void ErrorHandle()
        {
            label2.Text = "= ?";
        }
    }
}
