﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormZ2 : DiskMat.Module
    {
        public FormZ2()
        {
            Text = "Z_2";

            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            label2.Text = ") = ?";
        }
        public override void Run()
        {
            int answ = Z_2.Run(inputBox2.Value);
            //Console.WriteLine(inputBox2.Value);
            string s;
            switch(answ)
            {
                case 1: s = "\"+\""; break;
                case 2: s = "\"-\""; break;
                default: s = "\"0\""; break;
            }
            label2.Text = ") = " + s;
            
        }
    }
}
