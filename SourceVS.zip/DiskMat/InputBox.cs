﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace DiskMat
{
    /// <summary>
    /// Базовый класс элемента ввода данных. Соответствует типу Natural.
    /// </summary>
    public class InputBox : TextBox
    {
        //Форма, на которой обрабатываются ошибки ввода
        public Module Parent;

        //Регулярное выражение для Natural
        public virtual Regex Formula()
        {
           return new Regex(@"^\d*$");
        } 
        //При изменении текста - выполнить проверку
        protected override void OnTextChanged(EventArgs e)
        {
            base.OnTextChanged(e);
            if (new Regex("^0+$").IsMatch(Text))
                Text = "0";
            Validate();
            
        }

        //Проверка на ошибки. Если ошибки нет - предположить, что она исправлена, и сообщить об этом форме. Иначе - добавить ошибку.
        public bool Validate(bool runAfter = true)
        {
            bool ret = true;

            //Пустое поле
            if (this.Text.Length == 0)
            {
                Parent.AddError(this, Error.ErrorType.Empty);
                ret = false;
            }
            else
                Parent.FixError(this, Error.ErrorType.Empty);

            //Соответствие регулярному выражению
            if (Formula().IsMatch(Text))
                Parent.FixError(this, Error.ErrorType.Formula);
            else
            {
                Parent.AddError(this, Error.ErrorType.Formula);
                ret = false;
            }

            if (ret && runAfter)
                Parent.TryRun();

            return ret;
        }

        
        
    }
}
