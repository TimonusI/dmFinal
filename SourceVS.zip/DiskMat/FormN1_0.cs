﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormN1_0 : Module
    {
        public FormN1_0()
        {
            Text = "N_10";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            label2.Text = "= ?";
        }

        public override void Run()
        {
            label2.Text = "= " + N_10.Run(inputBox1.Value, inputBox2.Value);
            this.Width = label2.Location.X + label2.Width + 25;
        }

        public override void SpecialConditionHandle()
        {
            ErrorBorder(inputBox2);
            ErrorLabel.Text = "Второе число должно быть не больше первого";
            ErrorHandle();
        }
    }
}
