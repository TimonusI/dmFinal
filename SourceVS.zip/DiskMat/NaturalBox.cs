﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiskMat
{
    public class NaturalBox : InputBox
    {
        public Natural Value
        {
            get { return new Natural(this.Text); }
        }
    }
}
