﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormZ4 : DiskMat.Module
    {

        public FormZ4()
        {
            Text = "Z_4";

            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            label2.Text = " = ?";
        }
        public override void Run()
        {
            label2.Text = " = " + Z_4.Run(inputBox2.Value).ToString();

        }

        public override void Resize()
        {
            this.Width = label2.Location.X + label2.Width + 50;
        }
    }
}
