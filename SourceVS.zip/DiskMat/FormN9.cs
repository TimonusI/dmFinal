﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormN9 : DiskMat.Module
    {
        public FormN9()
        {
            Text = "N_9";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            label2.Text = "= ?";
        }

        public override void Run()
        {
            label2.Text = "= " + N_9.Run(inputBox1.Value, inputBox2.Value, naturalBox1.Value);
            this.Width = label2.Location.X + label2.Width + 25;
        }
    }
}
