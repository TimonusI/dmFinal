﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormN6 : DiskMat.Module
    {
        public FormN6()
        {
            Text = "N_6";
            InitializeComponent();
        }

        public override void Run()
        {
            label2.Text = "= " + N_6.Run(inputBox1.Value, Int32.Parse(inputBox2.Text));
            this.Width = label2.Location.X + label2.Width + 25;
        }

        public override void ErrorHandle()
        {
            label2.Text = "= ?";
        }
    }
}
