﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormZ9 : DiskMat.Module
    {

        public FormZ9()
        {
            Text = "Z_9";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            label2.Text = "= ?";
        }

        public override void Run()
        {
            label2.Text = "= " + Z_9.Run(inputBox1.Value, inputBox2.Value);
            this.Width = label2.Location.X + label2.Width + 25;
        }

        public override void SpecialConditionHandle()
        {
            if (inputBox2.Text == "0")
            {
                ErrorBorder(inputBox2);
                ErrorLabel.Text = "Деление на 0 недопустимо";
                ErrorHandle();
                Resize();
            }
            else
                label2.Text = "= 0";
        }
        public override void Resize()
        {
            this.Width = label2.Location.X + label2.Width + 25;
        }
    }
}
