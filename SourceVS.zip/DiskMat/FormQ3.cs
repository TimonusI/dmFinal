﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormQ3 : DiskMat.Module
    {

        public FormQ3()
        {
            Text = "Q_3";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            rationalLabel1.Unknown();
        }
        public override void Run()
        {
            rationalLabel1.Value = Q_3.Run(inputBox1.Value);
        }

        public override void Resize()
        {
            this.Width = 25 + rationalLabel1.Left + rationalLabel1.Width;
        }
    }
}
