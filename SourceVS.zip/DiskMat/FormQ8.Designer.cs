﻿namespace DiskMat
{
    partial class FormQ8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.rationalLabel1 = new DiskMat.RationalLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.rationalBox2 = new DiskMat.RationalBox();
            this.rationalBox1 = new DiskMat.RationalBox();
            this.SuspendLayout();
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.Location = new System.Drawing.Point(0, 70);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(35, 13);
            this.ErrorLabel.TabIndex = 43;
            this.ErrorLabel.Text = "label3";
            // 
            // rationalLabel1
            // 
            this.rationalLabel1.Location = new System.Drawing.Point(312, 19);
            this.rationalLabel1.Name = "rationalLabel1";
            this.rationalLabel1.Size = new System.Drawing.Size(22, 42);
            this.rationalLabel1.TabIndex = 42;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label2.Location = new System.Drawing.Point(290, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 17);
            this.label2.TabIndex = 41;
            this.label2.Text = "=";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.Location = new System.Drawing.Point(141, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(12, 17);
            this.label1.TabIndex = 40;
            this.label1.Text = "/";
            // 
            // rationalBox2
            // 
            this.rationalBox2.Location = new System.Drawing.Point(161, 12);
            this.rationalBox2.Name = "rationalBox2";
            this.rationalBox2.Size = new System.Drawing.Size(123, 53);
            this.rationalBox2.TabIndex = 39;
            // 
            // rationalBox1
            // 
            this.rationalBox1.Location = new System.Drawing.Point(10, 12);
            this.rationalBox1.Name = "rationalBox1";
            this.rationalBox1.Size = new System.Drawing.Size(123, 53);
            this.rationalBox1.TabIndex = 38;
            // 
            // FormQ8
            // 
            this.ClientSize = new System.Drawing.Size(344, 87);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.rationalLabel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rationalBox2);
            this.Controls.Add(this.rationalBox1);
            this.Name = "FormQ8";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ErrorLabel;
        private RationalLabel rationalLabel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private RationalBox rationalBox2;
        private RationalBox rationalBox1;
    }
}
