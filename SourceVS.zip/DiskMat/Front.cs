﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DiskMat
{
    /// <summary>
    /// Отображаемые ошибки
    /// Хаханов Тимофей
    /// </summary>
    public class Error
    {
        //Типы ошибок
        public enum ErrorType {Empty, Formula, SpecialCondition };

        //Текст ошибки
        public string text;

        //Элемент, содержащий ошибку
        public Control element;

        //Тип ошибки
        public ErrorType err;

        public Error(Control T, ErrorType E, string msg = "")
        {
            err = E;
            element = T;
            if(msg.Length>0)
                text = msg;
            else
                switch(E)//Стандартные тексты ошибок
                {
                    case ErrorType.Empty:
                        text = "Необходимо заполнить поле";
                        break;
                    case ErrorType.Formula:
                        text = "Несоответствие правилам ввода";
                        break;
                }
        }
    }
    /// <summary>
    /// Форма, фронт-энд модуля
    /// Хаханов Тимофей
    /// </summary>
    public class Module : Form
    {
        public List<Error> Errors;
        public Label ErrorLabel;

        


        /// <summary>
        /// Перезагружаемая функция, выполнение модуля
        /// </summary>
        public virtual void Run()
        {
            Console.WriteLine("Running module");
        }

        public virtual void ErrorHandle()
        {
            Console.WriteLine("Error handling");
        }

        //Попытка запуска, если нет ошибок
        public virtual void TryRun()
        {

            if (Errors.Count == 0)
            {
                try
                {
                    Run();
                    ErrorLabel.Text = "";
                }
                catch
                {
                    SpecialConditionHandle();
                }
            }
            else
                ErrorHandle();
            Resize();
        }


        public virtual void SpecialConditionHandle()
        {
            Console.WriteLine("SC handling...");
            try
            {
                ErrorLabel.Text = "SC faced with brave!";
            }
            catch
            {
                Console.WriteLine("Не удалось найти ErrorLabel");
                ErrorLabel = null;
            }

        }

        public virtual void SpecialConditionFix()
        {
            WriteError();
        }

        //Отрисовка ошибок
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            base.OnPaintBackground(e);
            foreach (Error E in Errors)
                ErrorBorder(E.element);
        }

        //Инициализация и первичный запуск модуля
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            //Icon = new Icon("i.ico");
            //FormBorderStyle = FormBorderStyle.FixedSingle;
            //MaximizeBox = false;

            //g = this.CreateGraphics();
            Errors = new List<Error>();
            //Попытка инициализации лэйбла, выводящего ошибки
            try
            {
                ErrorLabel = this.Controls.Find("ErrorLabel", true).First() as Label;
                ErrorLabel.ForeColor = Color.IndianRed;
                ErrorLabel.Text = "";
            }
            catch
            {
                Console.WriteLine("Не удалось найти ErrorLabel");
                ErrorLabel = null;
            }

            //Коллекция полей ввода
            var Inputs = (from Control C in this.Controls
                         where typeof(InputBox).IsAssignableFrom(C.GetType())
                         select C).ToList();

            var Rationals = from Control C in this.Controls
                           where typeof(RationalBox).IsAssignableFrom(C.GetType())
                           select C;
            foreach (RationalBox R in Rationals)
                R.SetParent(this);

            //Инициализация Parent-элементов полей, проверка стандартно-введенных данных
            foreach (InputBox I in Inputs)
            {
                I.Parent = this;
                I.Validate(false);
            }

            //Первичный запуск, если нет ошибок
            TryRun();
        }

        //Добавление ошибки
        public void AddError(TextBox C, Error.ErrorType ET, string text="")
        {
            var temp = from E in Errors
                       where E.element == C && E.err == ET
                       select E;
            if (temp.Count() == 0)
            {
                SpecialConditionFix();
                Errors.Add(new Error(C, ET, text));//Хранение в памяти
                ErrorBorder(C);//Отрисовка
                WriteError();//Вывод сообщения
            }
            ErrorHandle();

            Resize();
        }

        //Устранение ошибки
        public void FixError(TextBox C, Error.ErrorType ET)
        {
            //Если ошибка есть - устранить. Нет/не осталось - запустить модуль
            var temp = from E in Errors
                          where E.element == C && E.err == ET
                          select E;
            if (temp.Count() > 0)
            {
                Errors.Remove(temp.First());
                WriteError();
            }
            temp = from E in Errors
                       where E.element == C && E.err != Error.ErrorType.SpecialCondition
                       select E;
            if (temp.Count() == 0)
                ErrorBorder(C, false);
        }

        //Обвести ошибочный модуль
        public void ErrorBorder(Control C, bool red = true)
        {

            Graphics g = C.Parent.CreateGraphics();
            Pen p = new Pen(red ? Color.Red : SystemColors.Control);
            g.DrawRectangle(p, new Rectangle(C.Location.X-1, C.Location.Y-1, C.Width+1, C.Height+1));
        }

        //Вывести сообщение об ошибке
        public void WriteError()
        {
            if(ErrorLabel!=null)
                ErrorLabel.Text = Errors.Count > 0 ? Errors.First().text : "";
        }

        public virtual void Resize()
        {

        }

    }

    /// <summary>
    /// Ошибка дизайна модуля
    /// </summary>
    public class InvalidDisignException : Exception
    {
        public InvalidDisignException()
        {
        }

        public InvalidDisignException(string message)
        : base(message)
        {
        }

        public InvalidDisignException(string message, Exception inner)
        : base(message, inner)
        {
        }
    }
}
