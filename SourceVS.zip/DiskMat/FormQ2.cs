﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormQ2 : DiskMat.Module
    {
        public FormQ2()
        {
            Text = "Q_2";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            label1.Text = "- ?";
        }
        public override void Run()
        {
            if (Z_2.Run(rationalBox1.NumBox.Value) == 0)
                label1.Text = "- 0";
            else
                label1.Text = "- "+(Q_2.Run(rationalBox1.Value)?"целое":"дробное");
        }

        public override void Resize()
        {
            this.Width = 25 + label1.Left + label1.Width;
        }
    }
}
