﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormN1 : DiskMat.Module
    {
        public FormN1()
        {
            Text = "N_1";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            label1.Text = "?";
        }

        public override void Run()
        {
            string txt;

            switch(N_1.Run(new Natural(inputBox1.Text), new Natural(inputBox2.Text)))
            {
                case 1:
                    txt = ">";
                    break;
                case 2:
                    txt = "<";
                    break;
                default:
                    txt = "=";
                    break;
            }

            label1.Text = txt;
        }

    }
}
