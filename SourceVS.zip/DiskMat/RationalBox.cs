﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class RationalBox : UserControl
    {
        public RationalBox()
        {
            InitializeComponent();
        }

        public Digit Numerator
        {
            get { return NumBox.Value; }
        }

        public Natural Denominator
        {
            get { return DenomBox.Value; }
        }

        public string Text
        {
            get { return Value.ToString(); }
        }

        public void SetParent(Module P)
        {
            NumBox.Parent = P;
            DenomBox.Parent = P;
            NumBox.Validate();
            DenomBox.Validate();
        }

        public Rational Value
        {
            get { return new Rational(Numerator, Denominator); }
        }

        private void RationalBox_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Pen p = new Pen(Color.DarkGray, 1);
            int Y = (NumBox.Top + NumBox.Height + DenomBox.Top) / 2;
            g.DrawLine(p, NumBox.Left - 3, Y, NumBox.Left + NumBox.Width + 3, Y);

            if(Parent != null)
            {
                var errs = from E in (Parent as Module).Errors
                           where E.element == DenomBox || E.element == NumBox
                           select E;
                if (errs.Count() > 0)
                    foreach (Error E in errs)
                        (Parent as Module).ErrorBorder(E.element);
            }
        }
    }
}
