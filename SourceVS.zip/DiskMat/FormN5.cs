﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Linq;

namespace DiskMat
{
    public partial class FormN5 : DiskMat.Module
    {
        public FormN5()
        {
            Text = "N_5";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            label2.Text = "= ?";
        }


        public override void Run()
        {
            label2.Text = "= " + N_5.Run(inputBox1.Value, inputBox2.Value);
            this.Width = label2.Location.X + label2.Width + 25;
        }

        public override void SpecialConditionHandle()
        {
            ErrorBorder(inputBox2);
            ErrorLabel.Text = "Второе число должно быть не больше первого";
            ErrorHandle();
            Resize();
        }
    }
}
